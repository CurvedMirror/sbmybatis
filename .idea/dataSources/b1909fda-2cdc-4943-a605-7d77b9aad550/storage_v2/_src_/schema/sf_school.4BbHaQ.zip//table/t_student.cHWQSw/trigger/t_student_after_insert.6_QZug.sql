create definer = schoolfuture@`%` trigger t_student_AFTER_INSERT
  after INSERT
  on t_student
  for each row
BEGIN

END;

