create definer = schoolfuture@`%` trigger t_student_BEFORE_INSERT
  before INSERT
  on t_student
  for each row
BEGIN

END;

